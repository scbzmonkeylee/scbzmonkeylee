#!/usr/bin/env python3
import common
from common import *
from getpass import getpass
import subprocess
import argparse

####### START: Settings ######
# miners --plaintext--> go-proxy --tls--> f2pool fw
# Need to deploy:
#  supervisor
#  go-proxy
proxy_to_fw_solution = {
    # coin: port
    'btc': 3333,
    'ltc': 8888,
    'eth': 6688,
}

# miners --plaintext--> local haproxy --tls--> f2pool haproxy --plaintext--> f2pool pool
# Need to deploy:
#  haproxy
haproxy_to_haproxy_solution = {
    'etc': 8118,
    'mona': 20593,
    'bcd': 5610,
    'dgb-skein': 11113,
    'dgb-qubit': 11114,
    'dgb-odo': 11115,
    'zec': 3357,
    'rvc': 4800,
    'hns': 6000,
    'sc': 7788,
    #'dash': 5588,
    'dcr': 5730,
}

supported_coins = {**proxy_to_fw_solution, **haproxy_to_haproxy_solution}

####### END: Settings ######

def deploy(coins):
    docker_installed = False
    haproxy_installed = False
    proxy_env_ready = False
    init_common()
    
    for coin in coins:
        if coin not in supported_coins.keys():
            print("=" * 30)
            print(f"WARNING: {coin} is not supported yet")
            print("=" * 30)
        elif coin in haproxy_to_haproxy_solution.keys():
            if not docker_installed:
                init_docker()
                docker_installed = True
            if not haproxy_installed:
                init_haproxy()
                haproxy_installed = True

            deploy_coin = getattr(common, f'deploy_{coin}'.replace('-', '_'))
            deploy_coin()
        else:
            if not proxy_env_ready:
                # Intall supervisor
                init_proxy_to_fw_solution_env()
                proxy_env_ready = True
            # Download go proxy and add supervisor config for a coin
            deploy_coin = getattr(common, f'deploy_{coin}')
            deploy_coin()
    if haproxy_installed:
        haproxy_running, out = subprocess.getstatusoutput('docker ps -a | grep -q " haproxy$"')
        haproxy_cfg_valid, out = subprocess.getstatusoutput('docker exec -t haproxy /usr/sbin/haproxy -f /etc/haproxy -c')
        print(f"haproxy running code: {haproxy_running}")
        print(f"haproxy config is valid code: {haproxy_cfg_valid}")
        if int(haproxy_running) != 0 or int(haproxy_cfg_valid) == 0:
            run_shell('apt-get purge -y haproxy')
            run_shell('cd /home/ops/docker-haproxy && docker-compose stop && docker-compose rm -fv && docker-compose up -d')
    run_shell('apt-get update && apt-get upgrade -y --with-new-pkgs && apt-get autoremove -y')

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--coins", help=f"A list of coins to be deployed, comma seperated. e.g. {','.join(supported_coins.keys())}")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()
    coins = args.coins.split(',')
    deploy(coins)
    print("#" * 20)
    print("Port of each coin:")
    for coin in coins:
        try:
            print(f"    {coin}:\t{supported_coins[coin]}")
        except KeyError:
            pass
    print("#" * 20)
