import subprocess
import os
import sys
import traceback
import lsb_release
from multiprocessing import cpu_count
from datetime import datetime
from time import sleep

try:
    CODENAME = lsb_release.get_lsb_information()['CODENAME']
except AttributeError:
    CODENAME = lsb_release.get_distro_information()['CODENAME']

def run_shell(cmd):
    print(f"Running shell command: {cmd}")
    p = subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE)
    while True:
        out = p.stderr.read(1).decode()
        if out == '' and p.poll() != None:
            break
        if out != '':
            sys.stdout.write(out)
            sys.stdout.flush()

try:
    import requests
except:
    run_shell('apt-get update && apt-get install -y python3-pip')
    run_shell('python3 -m pip install requests')
    import requests

def init_common():
    user_name = os.environ.get('SUDO_USER', os.environ.get('USER'))
    print("Set up /etc/security/limits.conf")
    limits_conf = []
    with open('/etc/security/limits.conf', 'r') as fd:
        limits_conf = fd.readlines()
        if 'root soft nofile 65535\n' not in limits_conf:
            limits_conf.append('root soft nofile 65535\n')
        if 'root hard nofile 65535\n' not in limits_conf:
            limits_conf.append('root hard nofile 65535\n')
        if '* soft nofile 65535\n' not in limits_conf:
            limits_conf.append('* soft nofile 65535\n')
        if '* hard nofile 65535\n' not in limits_conf:
            limits_conf.append('* hard nofile 65535\n')
    
    if os.path.exists('/etc/security/limits.conf.new'):
        os.unlink('/etc/security/limits.conf.new')
    
    with open('/etc/security/limits.conf.new', 'a') as fd:
        for line in limits_conf:
            fd.write(line)
    
    os.rename('/etc/security/limits.conf.new', '/etc/security/limits.conf')
    print("Create user ops")
    run_shell('groupadd -g 5000 ops')
    run_shell('useradd -m -s /bin/bash -g 5000 -u 5000 ops')
    run_shell('apt-get purge -y unattended-upgrades update-manager-core')
    run_shell('apt-get install -y vim && update-alternatives --set editor /usr/bin/vim.basic')
    run_shell(f'mkdir -p /home/{user_name}/.ssh && chmod 700 /home/{user_name}/.ssh')
    ssh_pub_key = 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDDPDSOwGEJvT+lep6NCKIvYIg1EJkCYSoe8dQPI6NVq6VQCZ9bu/d6v7wTgY1+iwzEreHCxwiyszGmDcJY1zb8BDgYk997Hnj6SQ49TYh/WBZyvPRyHUYuFmTro7lC3/m3p35oRuUX07WuXUWbpPgJISMdZxya5vT9irzSOaVtNqjmkRKFt8m1EQ9ZB5aQyjh8oo69mzI5fBdZrB5HWK+2BnL0sOhGLUllT3tN6MYe5DpcXTS5fXLZT+phyrw10XUWuz3dIkicbtkHuwklxKw8Px/dKBeTGRs9/M6xVuwuMnI7GkMTHscumAv7zaJAgpgIolf9lr0Vcd7Y5f2b6pTN'
    with open(f'/home/{user_name}/.ssh/authorized_keys', 'w') as fd:
        fd.write(ssh_pub_key)
    run_shell(f'chmod 600 /home/{user_name}/.ssh/authorized_keys && chown -R {user_name}:{user_name} /home/{user_name}/.ssh')
    with open(f'/etc/sudoers.d/{user_name}', 'w') as fd:
        fd.write(f'{user_name} ALL=(ALL) NOPASSWD:ALL')
    run_shell('locale-gen en_US.UTF-8 && update-locale LANG=en_US.UTF-8')

def init_supervisor():
    print("Install supervisor")
    run_shell('apt-get update && apt-get install -y supervisor')
    supervisor_conf = '''
; supervisor config file

[unix_http_server]
file=/var/run/supervisor.sock   ; (the path to the socket file)
chmod=0700                       ; sockef file mode (default 0700)

[supervisord]
logfile=/var/log/supervisor/supervisord.log ; (main log file;default $CWD/supervisord.log)
pidfile=/var/run/supervisord.pid ; (supervisord pidfile;default supervisord.pid)
childlogdir=/var/log/supervisor            ; ('AUTO' child log dir, default $TEMP)
minfds=65535

; the below section must remain in the config file for RPC
; (supervisorctl/web interface) to work, additional interfaces may be
; added by defining them in separate rpcinterface: sections
[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface

[supervisorctl]
serverurl=unix:///var/run/supervisor.sock ; use a unix:// URL  for a unix socket

; The [include] section can just contain the "files" setting.  This
; setting can list multiple files (separated by whitespace or
; newlines).  It can also contain wildcards.  The filenames are
; interpreted as relative to this file.  Included files *cannot*
; include files themselves.

[include]
files = /etc/supervisor/conf.d/*.conf
'''
    with open('/etc/supervisor/supervisord.conf', 'w') as fd:
        fd.write(supervisor_conf)
    code, max_open_files = subprocess.getstatusoutput(''' cat /proc/`pgrep supervisord`/limits | grep "^Max open files" | awk '{print $4}' ''')
    if int(max_open_files) != 65535:
         run_shell("systemctl restart supervisor")

def init_proxy_to_fw_solution_env():
    init_supervisor()

def sort_servers_by_latency(backend_servers=[], ddos_servers=[]):
    for server in backend_servers:
        ip = server['ip']
        port = server['port']

        start = datetime.now()
        i = 0
        while i < 10:
            run_shell(f"/usr/bin/nc -vz -w 3 {ip} {port} > /dev/null")
            i += 1
            sleep(1)
        end = datetime.now()

        latency = float(((end - start).total_seconds() - 10) * 1000) / 10  # We nc 10 times, and sleep for 10s, so need to '- 10' and '/ 10'
        print(f"Latency to {server['ip']}: {latency}ms")
        server['latency'] = latency
    backend_servers = sorted(backend_servers, key=lambda item: item['latency'])
    return(','.join([f"{item['ip']}:{item['port']}" for item in backend_servers + ddos_servers]))


def deploy_btc():
    coin = 'btc'
    listen_ports = '3333'   # comma seperated
    proxy_version = 'proxy20210727a'
    backend_servers = [
        {'ip': '47.108.188.141', 'port': 587, 'latency': 10000},  # cncd
        {'ip': '39.104.161.183', 'port': 587, 'latency': 10000},  # hhht
    ]

    ddos_servers = [
        {'ip': '203.107.32.162', 'port': 587},  # cn
    ]
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    conn_each = 12
    share_interval = 30  # seconds
    wait = 1  # minutes
    print(f"Deploy {coin} proxy")
    proxy_download_url = f"https://oss-low-rate-public.oss-cn-huhehaote.aliyuncs.com/local_proxy/{proxy_version}"
    proxy_dir = f"/home/ops/src/{coin}-proxy"
    os.makedirs(proxy_dir, mode=0o755, exist_ok=True)
    os.chdir(proxy_dir)
    if not os.path.exists(proxy_version):
        resp = requests.get(proxy_download_url)
        if resp.status_code == 200:
            with open(proxy_version, 'wb') as fd:
                fd.write(resp.content)
        else:
            print(f"ERROR: Can't download {proxy_version}")
            sys.exit(1)
    os.chmod(proxy_version, 0o755)

    print(f"Set up {coin}'s supervisor config")
    supervisor_conf = f'''
[program:{coin}-proxy]
user=ops
environment=HOME=/home/ops
command=/home/ops/src/{coin}-proxy/{proxy_version} --port {listen_ports} --server {server_ips} --connEach {conn_each} --shareInterval {share_interval} --wait {wait}m
stdout_logfile=/var/log/supervisor/%(program_name)s.log
stdout_logfile_maxbytes=100MB
stdout_logfile_backups=10
redirect_stderr=true
autorestart=true
startretries=99999999
'''
    with open(f'/etc/supervisor/conf.d/{coin}-proxy.conf', 'w') as fd:
        fd.write(supervisor_conf)

    run_shell(f'[ -f /home/ops/docker-{coin}-fw/docker-compose.yml ] && cd /home/ops/docker-{coin}-fw && docker-compose stop && docker-compose rm -fv && cd .. && rm -rf docker-{coin}-fw')
    run_shell('supervisorctl update')

def deploy_ltc():
    coin = 'ltc'
    listen_ports = '8888'   # comma seperated
    proxy_version = 'proxy20210727a'
    backend_servers = [
        {'ip': '47.108.181.222', 'port': 993, 'latency': 10000},  # cncd
        {'ip': '39.104.207.211', 'port': 993, 'latency': 10000},  # hhht
    ]

    ddos_servers = [
        {'ip': '203.107.32.162', 'port': 993},  # cn
    ]
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    conn_each = 12
    share_interval = 15  # seconds
    wait = 1  # minutes
    print(f"Deploy {coin} proxy")
    proxy_download_url = f"https://oss-low-rate-public.oss-cn-huhehaote.aliyuncs.com/local_proxy/{proxy_version}"
    proxy_dir = f"/home/ops/src/{coin}-proxy"
    os.makedirs(proxy_dir, mode=0o755, exist_ok=True)
    os.chdir(proxy_dir)
    if not os.path.exists(proxy_version):
        resp = requests.get(proxy_download_url)
        if resp.status_code == 200:
            with open(proxy_version, 'wb') as fd:
                fd.write(resp.content)
        else:
            print(f"ERROR: Can't download {proxy_version}")
            sys.exit(1)
    os.chmod(proxy_version, 0o755)

    print(f"Set up {coin}'s supervisor config")
    supervisor_conf = f'''
[program:{coin}-proxy]
user=ops
environment=HOME=/home/ops
command=/home/ops/src/{coin}-proxy/{proxy_version} --port {listen_ports} --server {server_ips} --connEach {conn_each} --shareInterval {share_interval} --wait {wait}m
stdout_logfile=/var/log/supervisor/%(program_name)s.log
stdout_logfile_maxbytes=100MB
stdout_logfile_backups=10
redirect_stderr=true
autorestart=true
startretries=99999999
'''
    with open(f'/etc/supervisor/conf.d/{coin}-proxy.conf', 'w') as fd:
        fd.write(supervisor_conf)

    run_shell(f'[ -f /home/ops/docker-{coin}-fw/docker-compose.yml ] && cd /home/ops/docker-{coin}-fw && docker-compose stop && docker-compose rm -fv && cd .. && rm -rf docker-{coin}-fw')
    run_shell('supervisorctl update')

def deploy_eth():
    coin = 'eth'
    listen_ports = '6688'   # comma seperated
    proxy_version = 'proxy20211014etha'

    backend_servers = [
        {'ip': '47.108.171.174', 'port': 6688, 'latency': 10000},  # cncd
        {'ip': '39.104.160.251', 'port': 6688, 'latency': 10000},  # hhht
    ]

    ddos_servers = [
        {'ip': '203.107.32.162', 'port': 6688},  # cn
    ]
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    conn_each = 14
    diff_power = 33  # Default value 33
    wait = 1  # minutes
    print(f"Deploy {coin} proxy")
    proxy_download_url = f"https://oss-low-rate-public.oss-cn-huhehaote.aliyuncs.com/local_proxy/{proxy_version}"
    proxy_dir = f"/home/ops/src/{coin}-proxy"
    os.makedirs(proxy_dir, mode=0o755, exist_ok=True)
    os.chdir(proxy_dir)
    if not os.path.exists(proxy_version):
        resp = requests.get(proxy_download_url)
        if resp.status_code == 200:
            with open(proxy_version, 'wb') as fd:
                fd.write(resp.content)
        else:
            print(f"ERROR: Can't download {proxy_version}")
            sys.exit(1)
    os.chmod(proxy_version, 0o755)

    print(f"Set up {coin}'s supervisor config")
    supervisor_conf = f'''
[program:{coin}-proxy]
user=ops
environment=HOME=/home/ops
command=/home/ops/src/{coin}-proxy/{proxy_version} --port {listen_ports} --server {server_ips} --connEach {conn_each} --ethDiffPower {diff_power} --wait {wait}m
stdout_logfile=/var/log/supervisor/%(program_name)s.log
stdout_logfile_maxbytes=100MB
stdout_logfile_backups=10
redirect_stderr=true
autorestart=true
startretries=99999999
'''
    with open(f'/etc/supervisor/conf.d/{coin}-proxy.conf', 'w') as fd:
        fd.write(supervisor_conf)

    run_shell(f'[ -f /home/ops/docker-haproxy/haproxy/eth.cfg ] && cd /home/ops/docker-haproxy && rm -f ./haproxy/eth.cfg && docker-compose stop && docker-compose rm -fv && docker-compose up -d')
    run_shell('supervisorctl update')

def init_haproxy():
    # Set up docker-compose
    os.makedirs(f'/home/ops/docker-haproxy', mode=0o755, exist_ok=True)
    os.chown(f'/home/ops/docker-haproxy', 5000, 5000)
    os.makedirs(f'/home/ops/docker-haproxy/haproxy', mode=0o755, exist_ok=True)
    os.chown(f'/home/ops/docker-haproxy/haproxy', 5000, 5000)
    compose_conf = f'''
version: '3'
services:
    haproxy:
        image: f2pool-registry.cn-hangzhou.cr.aliyuncs.com/f2pool/haproxy:v2.0.13
        container_name: haproxy
        hostname: haproxy
        # This mode has the best performance
        network_mode: "host"
        dns:
            - 8.8.8.8
            - 114.114.114.114
        volumes:
            - /home/ops/docker-haproxy/haproxy/:/etc/haproxy/
        logging:
            driver: "json-file"
            options:
                max-size: "50M"
                max-file: "10"
        restart: always
'''

    with open(f'/home/ops/docker-haproxy/docker-compose.yml', 'w') as fd:
        fd.write(compose_conf)
    os.chown(f'/home/ops/docker-haproxy/docker-compose.yml', 5000, 5000)
    run_shell('cd /home/ops/docker-haproxy && docker-compose pull')

    cpu_num = cpu_count()
    nbproc_str = f'        nbproc {cpu_num}\n'
    i = 1
    while i <= cpu_num:
        cpu_map_str = f'        cpu-map {i} {i-1}\n'
        nbproc_str += cpu_map_str
        i += 1

    haproxy_global_conf = '''
listen stats
    bind 0.0.0.0:22222
    mode http
    timeout client      120000ms
    timeout server      120000ms
    timeout connect     120000ms
    log global
    stats enable
    stats realm Haproxy\ Statistics 
    stats uri /haproxy_stats
    stats hide-version
    stats auth admin:HA_dashboard

global
        log /dev/log    local0 warning
        log /dev/log    local1 warning
        chroot /var/lib/haproxy
        #stats socket /run/haproxy/admin.sock mode 660 level admin expose-fd listeners
        #stats timeout 30s
        user haproxy
        group haproxy
        daemon
        maxconn 60000

        # Default SSL material locations
        ca-base /etc/ssl/certs
        crt-base /etc/ssl/private

        # Default ciphers to use on SSL-enabled listening sockets.
        # For more information, see ciphers(1SSL). This list is from:
        #  https://hynek.me/articles/hardening-your-web-servers-ssl-ciphers/
        # An alternative list with additional directives can be obtained from
        #  https://mozilla.github.io/server-side-tls/ssl-config-generator/?server=haproxy
        ssl-default-bind-ciphers ECDH+AESGCM:DH+AESGCM:ECDH+AES256:DH+AES256:ECDH+AES128:DH+AES:RSA+AESGCM:RSA+AES:!aNULL:!MD5:!DSS
        #ssl-default-bind-options no-sslv3
        ssl-default-bind-options ssl-min-ver TLSv1.2
        ssl-server-verify none
''' + nbproc_str + '''

defaults
        mode tcp
        log global
        option tcplog
        option logasap
        timeout connect     12s
        timeout client      60s
        timeout server      60s
'''

    with open('/home/ops/docker-haproxy/haproxy/00_global.cfg', 'w') as fd:
        fd.write(haproxy_global_conf)


def init_docker():
    run_shell('apt-get update')
    run_shell('apt-get install -y python3-pip')
    run_shell('python3 -m pip install docker-compose -i https://mirrors.aliyun.com/pypi/simple')
    os.makedirs('/home/ops/log/fw', mode=0o755, exist_ok=True)
    os.chown('/home/ops/log', 5000, 5000)
    os.chown('/home/ops/log/fw', 5000, 5000)

    # Offical
    #run_shell('curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --yes --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg')
    #run_shell('echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list')

    # ustc mirror
    #run_shell('curl -fsSL https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu/gpg | sudo apt-key add -')
    #run_shell('echo "deb [arch=amd64] https://mirrors.ustc.edu.cn/docker-ce/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list')

    # Aliyun mirror
    run_shell('curl -fsSL http://mirrors.aliyun.com/docker-ce/linux/ubuntu/gpg | sudo apt-key add -')
    run_shell('echo "deb [arch=amd64] http://mirrors.aliyun.com/docker-ce/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list')
    code, out = subprocess.getstatusoutput('dpkg -l|grep -q "^ii  docker-ce"')
    if int(code) != 0:
        run_shell('apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release')
        run_shell('apt-get update && apt-get install -y docker-ce docker-ce-cli containerd.io')


def deploy_etc():
    coin = 'etc'
    haproxy_conf = '''
frontend etcpool
         bind *:8118
         default_backend etcpool_ssl

backend etcpool_ssl
         server etc_cncd_00 47.109.19.67:8180 ssl check inter 3000 fall 3 rise 2
'''

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_dgb_skein():
    coin = 'dgb-skein'
    algo = 'skein'
    backend_servers = [
        {'ip': '47.108.39.47', 'port': 11123, 'latency': 10000},  # cncd
        {'ip': '39.99.81.150', 'port': 11123, 'latency': 10000},  # hhht
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend dbg_skein
         bind *:11113
         default_backend dgb_skein_ssl

backend dgb_skein_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_dgb_qubit():
    coin = 'dgb-qubit'
    algo = 'qubit'

    backend_servers = [
        {'ip': '47.108.39.47', 'port': 11124, 'latency': 10000},  # cncd
        {'ip': '39.99.81.150', 'port': 11124, 'latency': 10000},  # hhht
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend dbg_qubit
         bind *:11114
         default_backend dgb_qubit_ssl

backend dgb_qubit_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_dgb_odo():
    coin = 'dgb-odo'
    algo = 'odo'

    backend_servers = [
        {'ip': '47.108.39.47', 'port': 11125, 'latency': 10000},  # cncd
        {'ip': '39.99.81.150', 'port': 11125, 'latency': 10000},  # hhht
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend dbg_odo
         bind *:11115
         default_backend dgb_odo_ssl
backend dgb_odo_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_zec():
    coin = 'zec'

    backend_servers = [
        {'ip': '47.108.189.60', 'port': 3367, 'latency': 10000},  # cncd
        {'ip': '39.104.133.72', 'port': 3367, 'latency': 10000},  # hhht
    ]

    ddos_servers = [
        {'ip': '203.107.32.162', 'port': 3367},  # cn
    ]
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend zec_fw
         bind *:3357
         default_backend zec_fw_ssl

backend zec_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_rvc():
    coin = 'rvc'

    backend_servers = [
        {'ip': '47.109.83.59', 'port': 4810, 'latency': 10000},  # cncd
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend rvc_fw
         bind *:4800
         default_backend rvc_fw_ssl
backend rvc_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_hns():
    coin = 'hns'

    backend_servers = [
        {'ip': '47.108.239.188', 'port': 6010, 'latency': 10000},  # cncd
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend hns_fw
         bind *:6000
         default_backend hns_fw_ssl
backend hns_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_sc():
    coin = 'sc'

    backend_servers = [
        {'ip': '121.89.207.173', 'port': 7798, 'latency': 10000},  # czjk
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend sc_fw
         bind *:7788
         default_backend sc_fw_ssl
backend sc_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_dash():
    coin = 'dash'
    backend_servers = [
        {'ip': '', 'port': 5598, 'latency': 10000},  # cncd
        {'ip': '', 'port': 5598, 'latency': 10000},  # hhht
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1
    # Set up haproxy
    haproxy_conf = '''
frontend dash_fw
         bind *:5588
         default_backend dash_fw_ssl

backend dash_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_dcr():
    coin = 'dcr'

    backend_servers = [
        {'ip': '120.55.88.72', 'port': 5740, 'latency': 10000},  # cnhz
    ]

    ddos_servers = []
    server_ips = sort_servers_by_latency(backend_servers, ddos_servers)

    backends = ''
    i = 0
    for backend in server_ips.split(','):
        if i == 0:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2\n"
        else:
            server_line = f"         server srv{i} {backend} ssl check inter 3000 fall 3 rise 2 backup\n"
        backends += server_line
        i += 1

    # Set up haproxy
    haproxy_conf = '''
frontend dcr_fw
         bind *:5730
         default_backend dcr_fw_ssl
backend dcr_fw_ssl
''' + backends

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_mona():
    coin = 'mona'
    # Set up haproxy
    haproxy_conf = '''
frontend monafw
         bind *:20593
         default_backend monafw_ssl

backend monafw_ssl
         server mona_cnhz_00 121.196.215.241:20590 ssl check inter 3000 fall 3 rise 2
'''

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)


def deploy_bcd():
    coin = 'bcd'
    # Set up haproxy
    haproxy_conf = '''
frontend bcdfw
         bind *:5610
         default_backend bcdfw_ssl

backend bcdfw_ssl
         server bcd_cnqd_00 47.104.108.39:5611 ssl check inter 3000 fall 3 rise 2
'''

    with open(f'/home/ops/docker-haproxy/haproxy/{coin}.cfg', 'w') as fd:
        fd.write(haproxy_conf)
